<?php
namespace MiniOrange\SP\Logger;

class Logger extends \Monolog\Logger
{
    
}