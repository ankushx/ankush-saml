<?php 
namespace MiniOrange\SP\Model;
class MiniorangeSamlIDPs extends \Magento\Framework\Model\AbstractModel{
	public function _construct(){
		$this->_init("MiniOrange\SP\Model\ResourceModel\MiniOrangeSamlIDPs");
	}
}